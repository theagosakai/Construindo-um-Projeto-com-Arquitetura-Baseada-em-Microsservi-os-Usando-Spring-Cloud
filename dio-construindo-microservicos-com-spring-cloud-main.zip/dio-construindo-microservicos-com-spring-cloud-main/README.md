<h1 align="center">DIO - Construindo um ecossistema com arquitetura baseada em Microsserviços usando Spring Cloud</h1>

<h2>1 - Introdução à Arquiteturas de Software: do Monolito ao Microsserviço</h2>

<div align="center" > 
  <img src="./assets/micro01.png" width="800px"/>
  <br/>
  <img src="./assets/micro02.png" width="800px"/>
  <br/>
  <img src="./assets/micro03.png" width="800px"/>
  <br/>
  <img src="./assets/micro04.png" width="800px"/>
  <br/>
  <img src="./assets/micro05.png" width="800px"/>
</div>

<h2>2 - Conhecendo o Ecossistema Spring Boot e Criando um Microsserviço de Catálogo de Produtos</h2>
  
  * Spring foi criado para resolver um problema comum no desenvolvimento de software que é interdependência entre objetos;
  * O Spring faz a inversão de controle, ele pega para ele o controle sobre as intâncias de objeto do sistema;
  * 

  <br/>

<div align="center"> 
  <img src="./assets/micro06.png" width="800px"/>
  <br/>
  <img src="./assets/micro07.jpg" width="800px"/>
  <br/>
</div>

<h2>3 - </h2>
<h2>4 - </h2>
<h2>5 - </h2>
<h2>6 - </h2>
<h2></h2>
<h2></h2>
<h2></h2>
<h2></h2>
<h2></h2>
